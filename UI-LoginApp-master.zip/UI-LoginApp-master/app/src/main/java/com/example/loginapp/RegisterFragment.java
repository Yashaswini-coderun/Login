package com.example.loginapp;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.Button;
import androidx.fragment.app.Fragment;


/**
 * A simple {@link Fragment} subclass.
 */
public class RegisterFragment extends Fragment {
    public Button button;

    public RegisterFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false);
        
        button.setOnClickListener(new View.OnClickListener() {
            private Object Intent;

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterFragment.this,HospitalRegister.class);
                this.sta
            }
        });
    }

    

}
